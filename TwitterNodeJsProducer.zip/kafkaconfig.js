// CHANGE THIS **************************************************************

var kafkaconfig = {
    kafkaHost: 'X.X.X.X:6667'
    };
    
    module.exports = {kafkaconfig};