// CHANGE THIS **************************************************************

var twitterconfig = {
    consumer_key: 'yourkey',
    consumer_secret: 'yoursecret',
    access_token_key: 'yourtoken',
    access_token_secret: 'yourtokensecret'  
    };
    
    module.exports = {twitterconfig};